<?php

// Definitions and globals.
define("__ROOT__", $_SERVER['DOCUMENT_ROOT']."/mobileapp/sora/visionbuilding");

 ?>