<?php

// Securities, disabled at the present.

 ?>