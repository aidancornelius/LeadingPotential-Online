<?
// 
// Copyright (c) 2011, Beaconsfield IT
// All rights reserved.
//
// This software was manufactured for Leading Potential (hereinafter The Company), 
// any use by The Company is acceptable, even excluding the conditions of this license.
// 
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//     * Neither the name of the Beaconsfield IT nor the
//       names of its contributors may be used to endorse or promote products
//       derived from this software without specific prior written permission.
//     * And; This software may not be redistributed and sold under 
//       any condition, even meeting the prior criteria(s).
//     * All advertising materials mentioning features or use of this software
//       must display the following acknowledgement:
//       This product includes software developed by Beaconsfield IT.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL BEACONSFIELD IT BE LIABLE FOR ANY
// DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//

function createbargraph($numcols, $col1, $col2, $col3, $col4, $col5, $col6, $col7) {
	
	$state = 1;
	// Check
	switch ($numcols) {
		case 1:
			break;
		case 2:
			break;
		case 3:
			break;
		case 4:
			break;
		case 5:
			$col1 = $col1; $col2 = $col2; $col3 = $col3; $col4 = $col4; $col5 = $col5; unset($col6); unset($col7);
			$cols = array("col" => array($col1, $col2, $col3, $col4, $col5));
			
			echo "\n<div id='graph1' style='width: 250px; position: relative; height: 200px; background: url(\"/resources/l1/g.raph.jpg\")'>";
			
				if(!empty($col1)) {
					echo "\n\n<div id='bar1' style='position: absolute; bottom: 0; left: 0; background-color: #000; color: #fff;  margin-left: 5px; width: 45px; height: $col1 px;'><center>$col1</center></div>";
				}
				if(!empty($col2)) {
					echo "\n\n<div id='bar2' style='position: absolute; bottom: 0; left: 50; background-color: #000; color: #fff;  margin-left: 5px; width: 45px; height: $col2 px;'><center>$col2</center></div>";					
				}
				if(!empty($col3)) {
					echo "\n\n<div id='bar3' style='position: absolute; bottom: 0; left: 100; background-color: #000; color: #fff;  margin-left: 5px; width: 45px; height: $col3 px;'><center>$col3</center></div>";					
				}
				if(!empty($col4)) {
					echo "\n\n<div id='bar4' style='position: absolute; bottom: 0; left: 150; background-color: #000; color: #fff;  margin-left: 5px; width: 45px; height: $col4 px;'><center>$col4</center></div>";					
				}
				if(!empty($col5)) {
					echo "\n\n<div id='bar5' style='position: absolute; bottom: 0; left: 200; background-color: #000; color: #fff;  margin-left: 5px; width: 45px; height: $col5 px;'><center>$col5</center></div>";					
				}
						
						
			echo "\n\n</div> "; 
			$state = 1;
			echo "\n\nRaw: \n\n";
			print_r($cols);
			return($state);
			$state = 0;
			break;
		case 6:
			break;
		case 7:
			break;
		default:
			return("Apollo Function Error: Invalid numcols, first var too > or <.");
			break;
}}

?>