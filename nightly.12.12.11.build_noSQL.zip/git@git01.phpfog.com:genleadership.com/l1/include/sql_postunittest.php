<font face="Courier New" size="2"></pre><form name="form1" method="post" action="unittest.php">
  [PHPCLI] su  
  <input type="text" name="username" id="username"> 
  -f -c "CallMySQL(); && RegisterGlobals(); && SetCookies(); && DumpCookieAsArray();"
  <input type="submit" name="su" id="su" value="Send to PHP CLI...">
</form></font>