<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>GenLeadership</title>
<style type="text/css">
body {
	background-color: #292931;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
body,td,th {
	color: #FFF;
	font-family: Geneva, sans-serif;
	font-size: 12px;
}
#spacetop {
	height: 8px;
	width: 50px;
}
.contentdiv {
	width: 95%;
	background: #3F484D;
	padding-top: 0.1px;
	padding-bottom: 0.1px;
	padding-left: 5px;
	padding-right: 5px;
	margin: auto;
	margin-top: 0px;
	margin-bottom: 15px;
	border-radius: 3px;	
}
</style>
</head>

<body>
<div id="spacetop"></div>
<div class="contentdiv" id="welcome"><p>Welcome to the Generative Leadership mobile resource application, use the buttons below to select a resource or module to access.</p><p>If you’re new to the app then you can view the getting started guide which is also shown below.</p><p>If you’re lost or need help feel free to use the forum or lore ipsum dolour sit amet something something else I like pie, pie is tasty how are you? that’s great, I like pie too! Flavourful ventures I see.</p></div>
<div class="contentdiv" id="welcome2"><p>Welcome to the Generative Leadership mobile resource application, use the buttons below to select a resource or module to access.</p><p>If you’re new to the app then you can view the getting started guide which is also shown below.</p><p>If you’re lost or need help feel free to use the forum or lore ipsum dolour sit amet something something else I like pie, pie is tasty how are you? that’s great, I like pie too! Flavourful ventures I see.</p></div>
</body>
</html>
