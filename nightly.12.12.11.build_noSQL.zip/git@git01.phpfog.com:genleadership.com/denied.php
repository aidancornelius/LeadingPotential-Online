﻿<?php require("header.php"); ?>
<div id="container">
  <table width="800" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="292"><img src="/resources/no-access.gif" width="292" height="283" alt="X"></td>
      <td width="508" align="left" valign="middle"><h2>You do not hold credentials to enter this zone.</h2>
      <p>Unfortunately at this time we can't allow you to access this area, if you believe this to be an error please contact technical support.</p>
      <p>Note: Directory 'roots' are not links to home, please use the navigation within the app or you will see this message.</p></td>
    </tr>
  </table>
</div>
<?php require("footer.php"); ?>