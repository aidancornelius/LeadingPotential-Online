<?php require("../header.php"); ?>
<div id="container">Loads <a href="viewmodule.php?action=view_modulecode_10">viewmodule.php?action=view_modulecode_10</a>.</div>
<?php require("../footer.php"); ?>