<div id="footer"><div style="float:left;">&copy; 2011 <a href="http://www.leadingpotential.com.au">Leading Potential</a>. A <a href="http://www.beaconsfieldit.net">Beaconsfield IT</a> project. This is version <a href="/l1/about.php">5812</a>. </div></div>
</body>
</html>