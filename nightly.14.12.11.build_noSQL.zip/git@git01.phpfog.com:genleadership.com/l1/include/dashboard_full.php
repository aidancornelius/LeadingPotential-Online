<h3>Hello <a href="profile.php"><?php echo $_COOKIE['firstname']; ?></a>! You're currently working on 1 module, you have 2 to complete and have completed 0.</h3>

<p>-Switch- if(person != completed survey1) {then (person -> method(Survey1))}.</p>

<p>[ Active and Recommended Modules ]<br /><br />
<a href="viewmodule.php?action=view_modulecode_10" class="module">[1] The basics, learning about you.</a>
<a href="viewmodule.php?action=view_modulecode_10" class="module">[1] Module One.</a></p>

<p>[ Other Modules ]<br /><br />
<a href="viewmodule.php?action=view_modulecode_10" class="module">[0] Module Zero.</a>
<a href="viewmodule.php?action=view_modulecode_10" class="module">[0] Module Zero-One.</a></p>

<p><a href="#" class="module">Server: <? echo getenv('SERVERNAME'); ?>. Date <? echo date('l \t\h\e jS \of F Y \a\n\d \i\t \i\s h:i:s A'); ?>. Node <? echo getenv('NODENAME'); ?>.</a></p>

<? // <a href="viewmodule.php?action=view_modulecode_10" class="module" style="background: #069;">Module 1.0 - Alpha Testing Module<br />Completeness: 5.0% - Click to continue</a> ?>
